// import {baseUrl} from "./utils";

var express = require("express");
var router = express.Router();
const request = require("request");
const guardianKey = "f6872563-96b1-4a81-9a24-e3cd249cc5e6";
const baseUrl = "http://localhost:8080";

function formatDate(date) {
    let d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
}

function resolveResults(results){
    let articles = [];
    for (let result of results){
        let article = {};
        try{
            let assets = result.blocks.main.elements[0].assets;
            article.image = assets[assets.length - 1].file;
        }catch (e) {
            console.log("picture not found: " + e);
            article.image = baseUrl + "/images/guardian.png";
        }
        try{
            article.title = result.webTitle;
            article.section = result.sectionId;
            article.date = formatDate(result.webPublicationDate);
            article.description = result.blocks.body[0].bodyTextSummary;
            article.url = result.webUrl;
            article.detailUrl = result.id;
            articles.push(article);
        }catch (e) {
            console.log(e)
        }
    }
    return articles;
}

function resolveDetailResult(content){
    let article = {};
    try{
        let assets = content.blocks.main.elements[0].assets;
        article.image = assets[assets.length - 1].file;
    }catch (e) {
        console.log(e);
        article.image = baseUrl + "/images/guardian.png";
    }
    try{
        article.title = content.webTitle;
        article.date = formatDate(content.webPublicationDate);
        article.description = content.blocks.body[0].bodyTextSummary;
        article.url = content.webUrl;
        article.detailUrl = content.webUrl;
        article.section = content.sectionId;
    }catch (e) {
        console.log("Missing data in detail article" + e);
    }
    // console.log(article);
    return article;
}

function resolveSearchResult(){
    let articles = [];
    for (let result of results){
        let article = {};
        try{
            let assets = result.blocks.main.elements[0].assets;
            article.image = assets[assets.length - 1].file;
        }catch (e) {
            console.log("picture not found: " + e);
            article.image = baseUrl + "/images/guardian.png";
        }
        try{
            article.title = result.webTitle;
            article.section = result.sectionId;
            article.date = formatDate(result.webPublicationDate);
            article.detailUrl = result.id;
            articles.push(article);
        }catch (e) {
            console.log(e)
        }
    }
}

router.get("/", function(req, res, next) {
    let url = "https://content.guardianapis.com/search?api-key=" + guardianKey + "&section=(sport|business|technology|politics)&show-blocks=all";
    request(url, function (err,response,body) {
        if(err || response.statusCode !== 200){
            return res.sendStatus(500);
        }else{
            let results = JSON.parse(body).response.results;
            let articles = resolveResults(results);
            // console.log(articles);
            res.send(articles);
        }
    })
});

router.get("/:section",function (req,res,next) {
    let url = "https://content.guardianapis.com/" + req.params.section + "?api-key=" + guardianKey + "&show-blocks=all";
    request(url,function (err,response,body) {
        if(err || response.statusCode !== 200){
            return res.sendStatus(500);
        }else{
            let results = JSON.parse(body).response.results;
            let articles = resolveResults(results);
            // console.log(articles);
            res.send(articles);
        }
    })
});

router.get("/article/*",function (req,res,next) {
    console.log(req.params[0]);
    let url = "https://content.guardianapis.com/" + req.params[0] + "?api-key=" + guardianKey + "&show-blocks=all";
    request(url,function (err,response,body) {
        if(err || response.statusCode !== 200){
            return res.sendStatus(500);
        }else{
            let detailResult = JSON.parse(body).response.content;
            let article = resolveDetailResult(detailResult);
            res.send(article);
        }
    })
});

router.get("/search/:query",function (req,res,next) {
    let url = "https://content.guardianapis.com/search?q=" + req.params.query + "&api-key=" + guardianKey + "&show-blocks=all";
    request(url,function (err,response,body) {
        if(err || response.statusCode !== 200){
            return res.sendStatus(500);
        }else{
            let results = JSON.parse(body).response.results;
            let articles = resolveResults(results);
            res.send(articles);
        }
    })
});

module.exports = router;